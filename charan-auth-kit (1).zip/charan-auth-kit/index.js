const path = require('path');

module.exports = {
  templateDir: path.join(__dirname, 'template'),
  version: require('./package.json').version,
};
