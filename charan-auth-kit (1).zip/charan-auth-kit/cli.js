#!/usr/bin/env node
'use strict';

const fs   = require('fs');
const path = require('path');

const c = {
  reset:  (s) => `\x1b[0m${s}\x1b[0m`,
  bold:   (s) => `\x1b[1m${s}\x1b[0m`,
  dim:    (s) => `\x1b[2m${s}\x1b[0m`,
  green:  (s) => `\x1b[32m${s}\x1b[0m`,
  cyan:   (s) => `\x1b[36m${s}\x1b[0m`,
  yellow: (s) => `\x1b[33m${s}\x1b[0m`,
  red:    (s) => `\x1b[31m${s}\x1b[0m`,
  blue:   (s) => `\x1b[34m${s}\x1b[0m`,
  magenta:(s) => `\x1b[35m${s}\x1b[0m`,
};

function printBanner() {
  console.log('');
  console.log(c.cyan(c.bold('  ╔═══════════════════════════════════════╗')));
  console.log(c.cyan(c.bold('  ║                                       ║')));
  console.log(c.cyan(c.bold('  ║   ⬡  charan-auth-kit  v1.0.0          ║')));
  console.log(c.cyan(c.bold('  ║   Full-stack JWT Auth Scaffold         ║')));
  console.log(c.cyan(c.bold('  ║                                       ║')));
  console.log(c.cyan(c.bold('  ╚═══════════════════════════════════════╝')));
  console.log('');
}

const log = {
  info:    (msg) => console.log(`  ${c.cyan('ℹ')}  ${msg}`),
  success: (msg) => console.log(`  ${c.green('✔')}  ${msg}`),
  warn:    (msg) => console.log(`  ${c.yellow('⚠')}  ${msg}`),
  error:   (msg) => console.log(`  ${c.red('✖')}  ${msg}`),
  step:    (msg) => console.log(`\n  ${c.bold(c.blue('▶'))}  ${c.bold(msg)}`),
  file:    (msg) => console.log(`     ${c.dim('+')} ${c.dim(msg)}`),
};

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath  = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
      log.file(destPath.replace(process.cwd() + path.sep, ''));
    }
  }
}

function main() {
  printBanner();

  const args       = process.argv.slice(2);
  const projectName = args[0] || 'my-auth-app';

  
  if (projectName === '--help' || projectName === '-h') {
    console.log('  Usage:');
    console.log(`    ${c.cyan('npx charan-auth-kit')} ${c.yellow('<project-name>')}\n`);
    console.log('  Examples:');
    console.log(`    ${c.dim('npx charan-auth-kit my-app')}`);
    console.log(`    ${c.dim('npx charan-auth-kit .')}\n`);
    process.exit(0);
  }

  const targetDir = path.resolve(process.cwd(), projectName);

  
  if (fs.existsSync(targetDir)) {
    const existing = fs.readdirSync(targetDir);
    if (existing.length > 0) {
      log.error(`Directory "${projectName}" already exists and is not empty.`);
      log.info('Choose a different name or delete the folder first.');
      process.exit(1);
    }
  }

  const templateDir = path.join(__dirname, 'template');

  
  log.step('Scaffolding AUTH-KIT-backend  (Express · JWT · bcrypt)');
  const backendDest = path.join(targetDir, 'AUTH-KIT-backend');
  copyDir(path.join(templateDir, 'backend'), backendDest);
  log.success('Backend files created');

  
  log.step('Scaffolding AUTH-KIT-frontend  (React · Vite · Axios)');
  const frontendDest = path.join(targetDir, 'AUTH-KIT-frontend');
  copyDir(path.join(templateDir, 'frontend'), frontendDest);
  log.success('Frontend files created');

  
  console.log('');
  console.log(c.green(c.bold('  ✨  Project created successfully!\n')));

  const rel = projectName === '.' ? '' : `cd ${projectName}\n  `;

  console.log('  ' + c.bold('Next steps:'));
  console.log('');
  console.log(c.dim(`  # ── Backend ──────────────────────`));
  console.log(`  ${rel}cd AUTH-KIT-backend`);
  console.log('  npm install');
  console.log('  node examples/app.js');
  console.log('');
  console.log(c.dim(`  # ── Frontend ─────────────────────`));
  console.log(`  ${rel}cd AUTH-KIT-frontend`);
  console.log('  npm install');
  console.log('  npm run dev');
  console.log('');
  console.log(`  ${c.dim('Backend runs on')}  ${c.cyan('http://localhost:3000')}`);
  console.log(`  ${c.dim('Frontend runs on')} ${c.cyan('http://localhost:5173')}`);
  console.log('');
  console.log('  ' + c.bold('Auth endpoints ready out of the box:'));
  console.log(`  ${c.green('POST')}  /auth/register`);
  console.log(`  ${c.green('POST')}  /auth/login`);
  console.log(`  ${c.blue('GET')}   /auth/me`);
  console.log('');
  console.log('  ' + c.dim('Built with ❤  by charan  ·  github.com/charan/charan-auth-kit'));
  console.log('');
}

main();
