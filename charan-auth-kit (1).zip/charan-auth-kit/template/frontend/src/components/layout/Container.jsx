import './Container.css';

export function Container({ children, narrow }) {
  return (
    <div className={`container ${narrow ? 'container--narrow' : ''}`}>
      {children}
    </div>
  );
}
