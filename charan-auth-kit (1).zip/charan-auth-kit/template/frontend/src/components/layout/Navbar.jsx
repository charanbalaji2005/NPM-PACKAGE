import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { ROUTES } from '../../constants/routes';
import './Navbar.css';

export function Navbar() {
  const { isAuthenticated, user, logout } = useAuth();

  return (
    <nav className="navbar">
      <Link to={ROUTES.HOME} className="navbar__brand">
        <span className="navbar__logo">⬡</span>
        auth-simple-kit
      </Link>
      <div className="navbar__actions">
        {isAuthenticated ? (
          <>
            <span className="navbar__user">{user?.name}</span>
            <button className="navbar__logout" onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <Link to={ROUTES.LOGIN} className="navbar__link">Login</Link>
            <Link to={ROUTES.REGISTER} className="navbar__cta">Get Started</Link>
          </>
        )}
      </div>
    </nav>
  );
}
