import './Input.css';

export function Input({ label, error, ...props }) {
  return (
    <div className={`input-field ${error ? 'input-field--error' : ''}`}>
      {label && <label className="input-field__label">{label}</label>}
      <input className="input-field__input" {...props} />
      {error && <span className="input-field__error">{error}</span>}
    </div>
  );
}
