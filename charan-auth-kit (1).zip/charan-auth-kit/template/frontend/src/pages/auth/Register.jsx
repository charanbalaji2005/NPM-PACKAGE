import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { registerUser } from '../../services/authService';
import { validateRegisterForm } from '../../utils/validators';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { ROUTES } from '../../constants/routes';
import './Auth.css';

export default function Register() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleChange(e) {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setErrors((err) => ({ ...err, [e.target.name]: '' }));
    setServerError('');
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const validationError = validateRegisterForm(form);
    if (validationError) {
      const field = validationError.toLowerCase().includes('name')
        ? 'name'
        : validationError.toLowerCase().includes('email')
        ? 'email'
        : 'password';
      setErrors({ [field]: validationError });
      return;
    }

    setLoading(true);
    try {
      const { token, user } = await registerUser(form);
      login(token, user);
      navigate(ROUTES.DASHBOARD);
    } catch (err) {
      setServerError(err.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-glow" />
      <div className="auth-card">
        <div className="auth-card__header">
          <div className="auth-card__icon">⬡</div>
          <h1 className="auth-card__title">Create account</h1>
          <p className="auth-card__subtitle">Start for free, no credit card needed</p>
        </div>

        {serverError && (
          <div className="auth-alert auth-alert--error">{serverError}</div>
        )}

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          <Input
            label="Name"
            type="text"
            name="name"
            placeholder="Your name"
            value={form.name}
            onChange={handleChange}
            error={errors.name}
            autoComplete="name"
          />
          <Input
            label="Email"
            type="email"
            name="email"
            placeholder="you@example.com"
            value={form.email}
            onChange={handleChange}
            error={errors.email}
            autoComplete="email"
          />
          <Input
            label="Password"
            type="password"
            name="password"
            placeholder="At least 8 characters"
            value={form.password}
            onChange={handleChange}
            error={errors.password}
            autoComplete="new-password"
          />
          <Button type="submit" loading={loading}>
            Create account
          </Button>
        </form>

        <p className="auth-card__footer">
          Already have an account?{' '}
          <Link to={ROUTES.LOGIN}>Sign in</Link>
        </p>
      </div>
    </div>
  );
}
