import { useAuth } from '../../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { ROUTES } from '../../constants/routes';
import './Dashboard.css';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate(ROUTES.LOGIN);
  }

  const initials = user?.name
    ? user.name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : '?';

  return (
    <div className="dashboard">
      <div className="dashboard__glow" />

      <div className="dashboard__container">
        {}
        <header className="dashboard__header">
          <div>
            <h1 className="dashboard__title">Dashboard</h1>
            <p className="dashboard__subtitle">You're authenticated 🎉</p>
          </div>
          <button className="dashboard__logout" onClick={handleLogout}>
            Sign out
          </button>
        </header>

        {/* Profile card */}
        <div className="dashboard__grid">
          <div className="dash-card dash-card--profile">
            <div className="dash-card__avatar">{initials}</div>
            <div className="dash-card__info">
              <h2 className="dash-card__name">{user?.name}</h2>
              <p className="dash-card__email">{user?.email}</p>
              <span className="dash-card__role">{user?.role}</span>
            </div>
          </div>

          {/* Token info */}
          <div className="dash-card dash-card--token">
            <div className="dash-card__label">JWT Token (stored in localStorage)</div>
            <code className="dash-card__token">
              {localStorage.getItem('token')?.slice(0, 60)}...
            </code>
          </div>

          {/* Stats */}
          <div className="dash-card dash-card--stats">
            <div className="stat">
              <span className="stat__value">✓</span>
              <span className="stat__label">Email verified</span>
            </div>
            <div className="stat">
              <span className="stat__value">✓</span>
              <span className="stat__label">Token active</span>
            </div>
            <div className="stat">
              <span className="stat__value">✓</span>
              <span className="stat__label">Role assigned</span>
            </div>
          </div>

          {/* Kit info */}
          <div className="dash-card dash-card--kit">
            <div className="dash-card__label">Powered by</div>
            <div className="dash-card__kit-name">⬡ auth-simple-kit</div>
            <p className="dash-card__kit-desc">
              JWT · bcrypt · Express · Role-based access
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
