import client from '../api/client';

export async function registerUser({ name, email, password }) {
  const res = await client.post('/auth/register', { name, email, password });
  return res.data.data; 
}

export async function loginUser({ email, password }) {
  const res = await client.post('/auth/login', { email, password });
  return res.data.data; 
}

export async function fetchMe() {
  const res = await client.get('/auth/me');
  return res.data.data.user;
}
