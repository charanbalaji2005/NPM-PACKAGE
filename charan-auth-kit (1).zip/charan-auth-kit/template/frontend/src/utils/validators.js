export function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validatePassword(password) {
  return password && password.length >= 8;
}

export function validateRegisterForm({ name, email, password }) {
  if (!name || name.trim().length < 2) return 'Name must be at least 2 characters';
  if (!validateEmail(email)) return 'Please enter a valid email';
  if (!validatePassword(password)) return 'Password must be at least 8 characters';
  return null;
}

export function validateLoginForm({ email, password }) {
  if (!validateEmail(email)) return 'Please enter a valid email';
  if (!password) return 'Password is required';
  return null;
}
