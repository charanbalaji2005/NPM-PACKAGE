# auth-frontend

> Demo frontend for `auth-simple-kit` — built with React + Vite.

## Stack

- React 18 + React Router v6
- Axios (with JWT interceptors)
- Vite
- CSS Variables design system (no Tailwind, no UI lib)

## Setup

```bash
npm install
npm run dev
```

Make sure the `auth-simple-kit` backend is running on `http://localhost:3000`.

## Structure

```
src/
 ├── api/          # Axios client with auth interceptors
 ├── components/   # Reusable UI (Button, Input, Navbar, ProtectedRoute)
 ├── context/      # AuthContext — global auth state
 ├── hooks/        # useAuth()
 ├── pages/        # Login, Register, Dashboard
 ├── services/     # API calls (register, login, fetchMe)
 ├── utils/        # Client-side validators
 └── constants/    # Route paths
```

## Features

- Register & login with form validation
- JWT stored in localStorage, sent via Authorization header
- Protected routes redirect unauthenticated users
- Auto-fetch current user on refresh via `/auth/me`
- Global logout with redirect
