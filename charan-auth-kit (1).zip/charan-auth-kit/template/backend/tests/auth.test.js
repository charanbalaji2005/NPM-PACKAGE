const request = require('supertest');
const express = require('express');
const { setupAuth, authMiddleware } = require('../index');

function createApp() {
  const app = express();
  app.use(express.json());
  setupAuth(app, { jwtSecret: 'test-secret', storage: 'memory' });
  app.get('/protected', authMiddleware, (req, res) => res.json({ ok: true, user: req.user }));
  return app;
}

describe('auth-simple-kit', () => {
  let app;
  let token;

  beforeEach(() => {
    app = createApp();
  });

  test('POST /auth/register - creates a user', async () => {
    const res = await request(app)
      .post('/auth/register')
      .send({ name: 'Alice', email: 'alice@example.com', password: 'password123' });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.token).toBeDefined();
    token = res.body.data.token;
  });

  test('POST /auth/register - rejects duplicate email', async () => {
    await request(app)
      .post('/auth/register')
      .send({ name: 'Alice', email: 'dup@example.com', password: 'password123' });

    const res = await request(app)
      .post('/auth/register')
      .send({ name: 'Alice2', email: 'dup@example.com', password: 'password123' });

    expect(res.status).toBe(409);
  });

  test('POST /auth/login - returns token', async () => {
    await request(app)
      .post('/auth/register')
      .send({ name: 'Bob', email: 'bob@example.com', password: 'password123' });

    const res = await request(app)
      .post('/auth/login')
      .send({ email: 'bob@example.com', password: 'password123' });

    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeDefined();
    token = res.body.data.token;
  });

  test('POST /auth/login - rejects wrong password', async () => {
    await request(app)
      .post('/auth/register')
      .send({ name: 'Carol', email: 'carol@example.com', password: 'password123' });

    const res = await request(app)
      .post('/auth/login')
      .send({ email: 'carol@example.com', password: 'wrongpassword' });

    expect(res.status).toBe(401);
  });

  test('GET /protected - blocks unauthenticated', async () => {
    const res = await request(app).get('/protected');
    expect(res.status).toBe(401);
  });

  test('GET /protected - allows valid token', async () => {
    const reg = await request(app)
      .post('/auth/register')
      .send({ name: 'Dave', email: 'dave@example.com', password: 'password123' });

    const res = await request(app)
      .get('/protected')
      .set('Authorization', `Bearer ${reg.body.data.token}`);

    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });
});
