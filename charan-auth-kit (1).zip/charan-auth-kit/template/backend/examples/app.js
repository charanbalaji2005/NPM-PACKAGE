const express = require('express');
const { setupAuth, authMiddleware, roleMiddleware } = require('../index');

const app = express();
app.use(express.json());

const { authMiddleware: protect, roleMiddleware: role } = setupAuth(app, {
  jwtSecret: 'super-secret-key',
  jwtExpiresIn: '7d',
  storage: 'memory',
});

app.get('/', (req, res) => res.json({ message: 'API is running' }));

app.get('/profile', authMiddleware, (req, res) => {
  res.json({ message: 'Your profile', user: req.user });
});

app.get('/admin', authMiddleware, roleMiddleware.requireRole('admin'), (req, res) => {
  res.json({ message: 'Admin dashboard' });
});

app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
  console.log('Try:  POST /auth/register  { name, email, password }');
  console.log('      POST /auth/login      { email, password }');
  console.log('      GET  /auth/me         Authorization: Bearer <token>');
});
