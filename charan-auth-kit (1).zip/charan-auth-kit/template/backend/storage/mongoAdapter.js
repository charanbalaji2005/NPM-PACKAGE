let User;

function getModel() {
  if (User) return User;

  const mongoose = require('mongoose');

  const schema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, default: 'user' },
    createdAt: { type: Date, default: Date.now },
  });

  User = mongoose.models.AuthUser || mongoose.model('AuthUser', schema);
  return User;
}

async function findByEmail(email) {
  const Model = getModel();
  return Model.findOne({ email }).lean();
}

async function createUser(data) {
  const Model = getModel();
  const user = new Model(data);
  await user.save();
  return user.toObject();
}

async function findById(id) {
  const Model = getModel();
  return Model.findById(id).lean();
}

async function deleteUser(id) {
  const Model = getModel();
  return Model.deleteOne({ _id: id });
}

module.exports = { findByEmail, createUser, findById, deleteUser };
