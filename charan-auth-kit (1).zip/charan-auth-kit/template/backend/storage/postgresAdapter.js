let pool;

function getPool() {
  if (pool) return pool;
  const { Pool } = require('pg');
  pool = new Pool({ connectionString: process.env.POSTGRES_URI });
  return pool;
}

async function findByEmail(email) {
  const { rows } = await getPool().query('SELECT * FROM users WHERE email = $1 LIMIT 1', [email]);
  return rows[0] || null;
}

async function createUser({ name, email, password, role }) {
  const { rows } = await getPool().query(
    'INSERT INTO users (name, email, password, role) VALUES ($1,$2,$3,$4) RETURNING *',
    [name, email, password, role]
  );
  return rows[0];
}

async function findById(id) {
  const { rows } = await getPool().query('SELECT * FROM users WHERE id = $1', [id]);
  return rows[0] || null;
}

async function deleteUser(id) {
  return getPool().query('DELETE FROM users WHERE id = $1', [id]);
}

module.exports = { findByEmail, createUser, findById, deleteUser };
