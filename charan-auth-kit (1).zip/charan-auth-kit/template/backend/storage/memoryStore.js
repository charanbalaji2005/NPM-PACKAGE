const { v4: uuidv4 } = require('crypto');

const users = new Map();

function generateId() {
  try {
    return require('crypto').randomUUID();
  } catch {
    return Date.now().toString(36) + Math.random().toString(36).slice(2);
  }
}

async function findByEmail(email) {
  for (const user of users.values()) {
    if (user.email === email) return user;
  }
  return null;
}

async function createUser(data) {
  const id = generateId();
  const user = { id, ...data, createdAt: new Date() };
  users.set(id, user);
  return user;
}

async function findById(id) {
  return users.get(id) || null;
}

async function deleteUser(id) {
  return users.delete(id);
}

module.exports = { findByEmail, createUser, findById, deleteUser };
