module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'change-me-in-production',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  bcryptRounds: 12,
  storage: 'memory', 
  mongoUri: process.env.MONGO_URI || '',
  postgresUri: process.env.POSTGRES_URI || '',
  allowedRoles: ['user', 'admin'],
  defaultRole: 'user',
};
