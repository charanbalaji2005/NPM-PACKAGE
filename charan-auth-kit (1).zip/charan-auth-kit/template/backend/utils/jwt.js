const jwt = require('jsonwebtoken');
const defaultConfig = require('../config/default');

function generateToken(payload, secret = defaultConfig.jwtSecret, expiresIn = defaultConfig.jwtExpiresIn) {
  return jwt.sign(payload, secret, { expiresIn });
}

function verifyToken(token, secret = defaultConfig.jwtSecret) {
  return jwt.verify(token, secret);
}

module.exports = { generateToken, verifyToken };
