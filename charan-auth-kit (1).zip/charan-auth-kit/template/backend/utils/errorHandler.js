class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
  }
}

function errorHandler(err, req, res, next) {
  const statusCode = err.statusCode || 500;
  const message = err.isOperational ? err.message : 'Something went wrong';

  if (process.env.NODE_ENV !== 'production') {
    console.error('[auth-simple-kit error]', err);
  }

  return res.status(statusCode).json({ success: false, message });
}

module.exports = errorHandler;
module.exports.AppError = AppError;
