function success(res, message, data = {}, statusCode = 200) {
  return res.status(statusCode).json({ success: true, message, data });
}

function badRequest(res, message) {
  return res.status(400).json({ success: false, message });
}

function unauthorized(res, message = 'Unauthorized') {
  return res.status(401).json({ success: false, message });
}

function forbidden(res, message = 'Forbidden') {
  return res.status(403).json({ success: false, message });
}

function serverError(res, message = 'Internal server error') {
  return res.status(500).json({ success: false, message });
}

module.exports = { success, badRequest, unauthorized, forbidden, serverError };
