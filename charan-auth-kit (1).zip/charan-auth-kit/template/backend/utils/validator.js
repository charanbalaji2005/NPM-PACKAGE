function validateRegister({ name, email, password } = {}) {
  if (!name || name.trim().length < 2) return { error: 'Name must be at least 2 characters' };
  if (!email || !isValidEmail(email)) return { error: 'Valid email is required' };
  if (!password || password.length < 8) return { error: 'Password must be at least 8 characters' };
  return { error: null };
}

function validateLogin({ email, password } = {}) {
  if (!email || !isValidEmail(email)) return { error: 'Valid email is required' };
  if (!password) return { error: 'Password is required' };
  return { error: null };
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

module.exports = { validateRegister, validateLogin };
