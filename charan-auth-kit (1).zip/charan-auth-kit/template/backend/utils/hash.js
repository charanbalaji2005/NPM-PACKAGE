const bcrypt = require('bcryptjs');

async function hashPassword(password, rounds = 12) {
  return bcrypt.hash(password, rounds);
}

async function comparePassword(plain, hashed) {
  return bcrypt.compare(plain, hashed);
}

module.exports = { hashPassword, comparePassword };
