const { hashPassword, comparePassword } = require('../utils/hash');
const { generateToken } = require('../utils/jwt');
const { AppError } = require('../utils/errorHandler');
const memoryStore = require('../storage/memoryStore');

function getStore(config) {
  if (config.storage === 'mongo') return require('../storage/mongoAdapter');
  if (config.storage === 'postgres') return require('../storage/postgresAdapter');
  return memoryStore;
}

async function register(body, config) {
  const store = getStore(config);
  const { email, password, name } = body;

  const existing = await store.findByEmail(email);
  if (existing) throw new AppError('Email already in use', 409);

  const hashed = await hashPassword(password, config.bcryptRounds);
  const user = await store.createUser({
    name,
    email,
    password: hashed,
    role: config.defaultRole,
  });

  const token = generateToken(
    { id: user.id, email: user.email, role: user.role },
    config.jwtSecret,
    config.jwtExpiresIn
  );

  return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
}

async function login(body, config) {
  const store = getStore(config);
  const { email, password } = body;

  const user = await store.findByEmail(email);
  if (!user) throw new AppError('Invalid email or password', 401);

  const valid = await comparePassword(password, user.password);
  if (!valid) throw new AppError('Invalid email or password', 401);

  const token = generateToken(
    { id: user.id, email: user.email, role: user.role },
    config.jwtSecret,
    config.jwtExpiresIn
  );

  return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
}

module.exports = { register, login };
