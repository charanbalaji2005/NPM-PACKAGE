const authService = require('../services/authService');
const { validateRegister, validateLogin } = require('../utils/validator');
const { success, badRequest } = require('../utils/response');

async function register(req, res, next, config) {
  try {
    const { error } = validateRegister(req.body);
    if (error) return badRequest(res, error);

    const result = await authService.register(req.body, config);
    return success(res, 'User registered successfully', result, 201);
  } catch (err) {
    next(err);
  }
}

async function login(req, res, next, config) {
  try {
    const { error } = validateLogin(req.body);
    if (error) return badRequest(res, error);

    const result = await authService.login(req.body, config);
    return success(res, 'Login successful', result);
  } catch (err) {
    next(err);
  }
}

function me(req, res) {
  return success(res, 'Authenticated user', { user: req.user });
}

module.exports = { register, login, me };
