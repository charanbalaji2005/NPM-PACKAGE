const authRoutes = require('./routes/authRoutes');
const authMiddleware = require('./middleware/authMiddleware');
const roleMiddleware = require('./middleware/roleMiddleware');
const errorHandler = require('./utils/errorHandler');
const defaultConfig = require('./config/default');

function setupAuth(app, options = {}) {
  const config = { ...defaultConfig, ...options };

  
  app.set('authConfig', config);

  
  app.use('/auth', authRoutes(config));

  
  app.use(errorHandler);

  return { authMiddleware, roleMiddleware };
}

module.exports = {
  setupAuth,
  authMiddleware,
  roleMiddleware,
};
