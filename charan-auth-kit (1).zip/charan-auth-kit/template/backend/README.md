# auth-simple-kit

> Plug-and-play JWT authentication middleware for Express apps. One line setup, zero boilerplate.

## Install

```bash
npm install auth-simple-kit
```

## Quick Start

```js
const express = require('express');
const { setupAuth, authMiddleware, roleMiddleware } = require('auth-simple-kit');

const app = express();
app.use(express.json());

setupAuth(app, {
  jwtSecret: 'your-secret',
  storage: 'memory', // or 'mongo' or 'postgres'
});

// Protected route
app.get('/dashboard', authMiddleware, (req, res) => {
  res.json({ user: req.user });
});

// Admin only
app.delete('/users/:id', authMiddleware, roleMiddleware.requireRole('admin'), handler);
```

## Endpoints (auto-registered)

| Method | Path             | Description        |
|--------|------------------|--------------------|
| POST   | /auth/register   | Register new user  |
| POST   | /auth/login      | Login, get token   |
| GET    | /auth/me         | Get current user   |

## Config Options

| Key            | Default         | Description                        |
|----------------|-----------------|------------------------------------|
| jwtSecret      | `change-me`     | Secret for signing tokens          |
| jwtExpiresIn   | `7d`            | Token expiry                       |
| bcryptRounds   | `12`            | Bcrypt salt rounds                 |
| storage        | `memory`        | `memory`, `mongo`, `postgres`      |
| mongoUri       | `''`            | MongoDB connection string          |
| postgresUri    | `''`            | PostgreSQL connection string       |
| defaultRole    | `user`          | Role assigned to new users         |

## Storage Adapters

### In-Memory (default)
No setup needed. Data resets on server restart. Great for development.

### MongoDB
```bash
npm install mongoose
```
```js
setupAuth(app, { storage: 'mongo', mongoUri: 'mongodb://localhost/mydb' });
```

### PostgreSQL
```bash
npm install pg
```
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT DEFAULT 'user',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```
```js
setupAuth(app, { storage: 'postgres', postgresUri: 'postgresql://localhost/mydb' });
```

## Tests

```bash
npm test
```

## License

MIT
