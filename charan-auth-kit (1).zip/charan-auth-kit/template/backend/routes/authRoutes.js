const express = require('express');
const { register, login, me } = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

function authRoutes(config) {
  const router = express.Router();

  
  router.post('/register', (req, res, next) => register(req, res, next, config));

  
  router.post('/login', (req, res, next) => login(req, res, next, config));

  
  router.get('/me', authMiddleware, (req, res) => me(req, res));

  return router;
}

module.exports = authRoutes;
